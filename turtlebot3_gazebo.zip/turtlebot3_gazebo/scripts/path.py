#!/usr/bin/env python 

#import library ros 
import rospy 
import time
import math


#import library untuk mengirim command dan menerima data navigasi dari quadcopter
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String 
from std_msgs.msg import Empty 

from nav_msgs.msg import Odometry

#import class status untuk menentukan status ddari quadcopter
#from drone_status import DroneStatus

COMMAND_PERIOD = 1000

      

class path():
    def __init__(self):
	print '############################################################'
	print '                                              '
	self.state = int(input("Enter 1 or 2 :"))

	if self.state==1:
		self.X_d =[1,2]
		self.Y_d =[0,0]
		self.Z_d =[0,0]
	elif 	self.state==2:
		self.X_d =[-0.5,-1]
		self.Y_d =[0,0]
		self.Z_d =[0,0]

	
        print '############################################################'
	
	self.X=0
	self.Y=0
	self.Z=0
	self.W=1
        
	self.status = ""
        rospy.init_node('path', anonymous=False)

	self.rate_num=10.0
        self.rate = rospy.Rate(self.rate_num)

        self.pubGoal = rospy.Publisher("/move_base_simple/goal",PoseStamped, queue_size=10)


	self.subs=rospy.Subscriber('/odom', Odometry, self.callback)



	#self.subs=rospy.Subscriber("ardrone_1/sonar_height", Odometry, self.callback)
        self.command = PoseStamped()
        #self.commandTimer = rospy.Timer(rospy.Duration(COMMAND_PERIOD/1000.0),self.SendCommand)
        self.state_change_time = rospy.Time.now()    

	self.Z=0

    def callback(self,Odometry):

        self.X=Odometry.pose.pose.position.x
        self.Y=Odometry.pose.pose.position.y
	self.Z=Odometry.pose.pose.position.z
	self.W=Odometry.pose.pose.orientation.w
	
	   

        
    def SetCommand(self, x, y, o_w):
	print 'sub callback'
        self.command.header.frame_id = "map"
	self.command.header.stamp = rospy.Time.now()  
        self.command.pose.position.x = x
        self.command.pose.position.y = y
        self.command.pose.orientation.w = o_w
        self.pubGoal.publish(self.command)


if __name__ == '__main__': 

    try: 
              
        tb3 = path()
	i=0
        print '############################################################'
	
	print tb3.X_d[0],tb3.Y_d[0]

	tb3.SetCommand(tb3.X_d[0],tb3.Y_d[0],1,)
        while not rospy.is_shutdown():



		if ((tb3.X_d[i]-tb3.X)**2+ (tb3.Y_d[i]-tb3.Y)**2)**0.5<0.1:
	        	print 'enter if'
			i=i+1;	        	
			tb3.SetCommand(tb3.X_d[i],tb3.Y_d[i],1)
        
    except rospy.ROSInterruptException:
        pass

