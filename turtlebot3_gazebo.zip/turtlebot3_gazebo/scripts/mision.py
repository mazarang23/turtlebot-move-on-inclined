#!/usr/bin/env python
# license removed for brevity

import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from nav_msgs.msg import Odometry
class path():
    def __init__(self):
	print '############################################################'
	print '                                              '
	self.state = int(input("Enter 1 or 2 :"))

	if self.state==1:
		self.X_d =[1,2,3,4,4.1,4.15,4.3]
		self.Y_d =[0,0,-0.1,0.2,0.6,1.1,1.5]
		self.Z_d =[0,0,0,0,0,0,0]

	elif 	self.state==2:
		self.X_d =[1,2,3,4,4.5]
		self.Y_d =[0,0,0,-0.5,-1.4]
		self.Z_d =[0,0,0,0,0]

	rospy.init_node('movebase_client_py')

	self.subs=rospy.Subscriber('/odom', Odometry, self.callback)
        print '############################################################'
    def callback(self,Odometry):

        self.X=Odometry.pose.pose.position.x
        self.Y=Odometry.pose.pose.position.y
	self.Z=Odometry.pose.pose.position.z
	self.W=Odometry.pose.pose.orientation.w

    def movebase_client(self, x,y):    
	    client = actionlib.SimpleActionClient('move_base',MoveBaseAction)
	    client.wait_for_server()

	    goal = MoveBaseGoal()
	    goal.target_pose.header.frame_id = "map"
	    goal.target_pose.header.stamp = rospy.Time.now()
	
	    goal.target_pose.pose.position.x = x
	    goal.target_pose.pose.position.y = y
	    goal.target_pose.pose.orientation.w = 1.0

	    client.send_goal(goal)

if __name__ == '__main__':
    try:

        tb3=path()
	i=0
        print '############################################################'
	


	tb3.movebase_client(tb3.X_d[0],tb3.Y_d[0])
        
	while not rospy.is_shutdown():
		if i<len(tb3.X_d):
			if ((tb3.X_d[i]-tb3.X)**2+ (tb3.Y_d[i]-tb3.Y)**2)**0.5<0.4:

				i=i+1;	        	
				tb3.movebase_client(tb3.X_d[i],tb3.Y_d[i])
		elif  i>len(tb3.X_d):
			break
		

        if result:
            rospy.loginfo("Goal execution done!")
    except rospy.ROSInterruptException:
        rospy.loginfo("Navigation test finished.")

